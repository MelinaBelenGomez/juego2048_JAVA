package interfaz;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JTextField;

public class PantallaMenu{

	public JFrame frame;
	private JTextField jugador;
	public static String nombreJugador;
	

	public PantallaMenu() {
		initialize();
		
		
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 662, 515);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel panel = new JPanel();
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel nombreUsuarioLabel = new JLabel("Ingresá tu nombre:");
		nombreUsuarioLabel.setBackground(new Color(245, 245, 220));
		nombreUsuarioLabel.setForeground(new Color(239, 128, 80));
		nombreUsuarioLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 25));
		nombreUsuarioLabel.setBounds(50, 266, 228, 46);
		panel.add(nombreUsuarioLabel);
		
		jugador = new JTextField();
		jugador.setFont(new Font("Comic Sans MS", Font.PLAIN, 28));
		jugador.setBounds(293, 269, 191, 36);
		panel.add(jugador);
		jugador.setColumns(10);

		
		
		JButton iniciarJuego = new JButton(""); //iniciar juego

		iniciarJuego.setBounds(233, 399, 191, 54);
		panel.add(iniciarJuego);
		iniciarJuego.setForeground(new Color(204, 153, 204));
		iniciarJuego.setIcon(new ImageIcon(PantallaMenu.class.getResource("/images/IniciarJuego_img.png")));
		iniciarJuego.setBackground(new Color(239, 128, 80));
		iniciarJuego.setBorder(BorderFactory.createLineBorder(new Color(0,0,0,0)));
		
		
		JLabel lblNewLabel_2 = new JLabel("Titulo1");
		lblNewLabel_2.setIcon(new ImageIcon(PantallaMenu.class.getResource("/images/2048_img.png")));
		lblNewLabel_2.setBounds(132, 88, 321, 110);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("FondoMenu");
		lblNewLabel.setBackground(new Color(153, 102, 51));
		lblNewLabel.setIcon(new ImageIcon(PantallaMenu.class.getResource("/images/fondoMenu.jpg")));
		lblNewLabel.setBounds(10, 0, 640, 449);
		panel.add(lblNewLabel);
		

		

		//cuando se apreta el boton iniciarjuego se tiene que abrir la sig ventana.
		
		iniciarJuego.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	nombreJugador=jugador.getText();
		    	
		    	VentanaJuego2048 ventana = new VentanaJuego2048();
		        ventana.setVisible(true);
		        
		     // Cerrar la ventana actual
		        frame.dispose();
		    } 
		});
		
	}
	public static String getNombre()
{
		return nombreJugador;
		}
}
