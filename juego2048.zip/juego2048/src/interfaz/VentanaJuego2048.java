package interfaz;

import javax.swing.*;
import javax.swing.border.Border;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Collections;

import logica.Juego;

public class VentanaJuego2048 extends JFrame implements KeyListener {

	private JPanel panelTablero;
	private JPanel panelSuperior;
	private JPanel panelDerecho;
	private JPanel panelIzquierdo;
	private JPanel panelInferior;
	private Juego juego;
	private JLabel etiquetaPuntaje; 
	private JLabel etiquetaMovimientos;
	private JLabel gamerLabel;
	private JLabel etiquetaJugadorActual;
	private String gamer;
	private ArrayList<String> tablaPosiciones = new ArrayList<>(); //PARA QUE SE GUARDEN LOS NOMBRES Y PUNTAJES

	public VentanaJuego2048() {  

		setTitle("2048 Game");
		setSize(760, 614); // Establecer tamaño de la ventana
		
		gamer= PantallaMenu.getNombre();
		this.juego = new Juego(gamer); // INICIO EL JUEGO
		setLocationRelativeTo(null); // Centrar la ventana en la pantalla
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		initComponents(); // PARA INICIAR LOS PANELES Y TABLERO
		addKeyListener(this); // PARA LAS TECLAS
		
		
		

	}

	private void initComponents() {
		getContentPane().setLayout(new BorderLayout());

		// Panel superior
		
		panelSuperior = new JPanel();
		panelSuperior.setPreferredSize(new Dimension(getWidth(), 130));
		panelSuperior.setBackground(new Color(255, 232, 208));
		getContentPane().add(panelSuperior, BorderLayout.NORTH);
		panelSuperior.setLayout(null);
		etiquetaPuntaje = new JLabel("0");
		etiquetaPuntaje.setForeground(new Color(255, 128, 64));
		etiquetaPuntaje.setFont(new Font("Comic Sans MS", Font.BOLD, 35));
		etiquetaPuntaje.setBounds(657, 28, 103, 47);
		panelSuperior.add(etiquetaPuntaje);

		etiquetaMovimientos = new JLabel("0");
		etiquetaMovimientos.setForeground(new Color(255, 128, 64));
		etiquetaMovimientos.setFont(new Font("Comic Sans MS", Font.BOLD, 35));
		etiquetaMovimientos.setBounds(657, 70, 103, 50);
		panelSuperior.add(etiquetaMovimientos);
		
		JLabel PuntajeLabel = new JLabel("");
		PuntajeLabel.setIcon(new ImageIcon(VentanaJuego2048.class.getResource("/images/puntaje.png")));
		PuntajeLabel.setBounds(460, 28, 173, 47);
		panelSuperior.add(PuntajeLabel);
		
		JLabel cantMovsLabel = new JLabel("");
		cantMovsLabel.setIcon(new ImageIcon(VentanaJuego2048.class.getResource("/images/cantMov1.png")));
		cantMovsLabel.setBounds(323, 70, 324, 60);
		panelSuperior.add(cantMovsLabel);
		
		gamerLabel = new JLabel("");
		gamerLabel.setIcon(new ImageIcon(VentanaJuego2048.class.getResource("/images/gamer.png")));
		gamerLabel.setHorizontalAlignment(SwingConstants.CENTER);
		gamerLabel.setBounds(40, 10, 163, 47);
		panelSuperior.add(gamerLabel);
		
		etiquetaJugadorActual = new JLabel(gamer);
		etiquetaJugadorActual.setForeground(new Color(255, 128, 64));
		etiquetaJugadorActual.setFont(new Font("Comic Sans MS", Font.PLAIN, 30));
		etiquetaJugadorActual.setHorizontalAlignment(SwingConstants.CENTER);
		etiquetaJugadorActual.setBounds(20, 55, 208, 38);
		panelSuperior.add(etiquetaJugadorActual);

		// Panel derecho
		panelDerecho = new JPanel();
		panelDerecho.setPreferredSize(new Dimension(160, getHeight() - 60));
		panelDerecho.setBackground(new Color(255, 192, 162));
		getContentPane().add(panelDerecho, BorderLayout.EAST);

		// Panel izquierdo
		panelIzquierdo = new JPanel();
		panelIzquierdo.setPreferredSize(new Dimension(160, getHeight() - 60));
		panelIzquierdo.setBackground(new Color(255, 192, 162));
		getContentPane().add(panelIzquierdo, BorderLayout.WEST);

		
	    

	 // Panel central 
	    panelTablero = new JPanel();
	    panelTablero.setLayout(new GridLayout(4, 4));
	    panelTablero.setBackground(new Color(209, 187, 158));
	    getContentPane().add(panelTablero, BorderLayout.CENTER);

	    // CREA EL TABLERO
	    for (int i = 0; i < 16; i++) {
	        JLabel celda = new JLabel("", SwingConstants.CENTER);
	        celda.setBorder(BorderFactory.createLineBorder(Color.BLACK));
	        Border borde = BorderFactory.createLineBorder(new Color(119, 107, 93), 6);
	        celda.setBorder(borde);
	        celda.setOpaque(true);
	        celda.setPreferredSize(new Dimension(30, 30));
	        panelTablero.add(celda);
	    }

	    
	   
	    actualizarMatriz();
	    
	    
	    
	 // Panel inferior
	 		panelInferior = new JPanel();
	 		panelInferior.setPreferredSize(new Dimension(getWidth(), 100));
	 		panelInferior.setBackground(new Color(255, 232, 208));
	 		getContentPane().add(panelInferior, BorderLayout.SOUTH);
	 		panelInferior.add(Box.createVerticalStrut(80), BorderLayout.SOUTH);
	 		
	 		
	 	    
	 	
	}

	// ACTUALIZO LA MATRIZ CON LOS VALORES DEL TABLERO QUE SE CREA EN EL JUEGO
	private void actualizarMatriz() {
	    Component[] componentes = panelTablero.getComponents();
	    int[][] matrizTablero = juego.dameTablero();
	    int indice = 0;
	    for (int i = 0; i < matrizTablero.length; i++) {
	        for (int j = 0; j < matrizTablero[i].length; j++) {
	            JLabel celda = (JLabel) componentes[indice];
	            if (matrizTablero[i][j] != 0) {
	            	celda.setFont(new Font("Comic Sans MS", Font.BOLD, 30));
	            	celda.setForeground(new Color(68, 55, 55));
	            	
	                celda.setText(String.valueOf(matrizTablero[i][j]));
	            } else {
	                celda.setText(""); // muestra string vacio cuando es un 0
	            }
	            celda.setBackground(obtenerColorParaNumero(matrizTablero[i][j]));
	            indice++;
	        }
	    }
	}

	

	// CODIGO PARA LAS TECLAS Y EL CICLO DEL JUEGO (SE PUEDEN USAR LAS FLECHAS Y LAS TECLAS "ASDW"
	
	@Override
	public void keyPressed(KeyEvent e) {
	    int keyCode = e.getKeyCode();
	    switch (keyCode) {
	        case KeyEvent.VK_UP:
	        case KeyEvent.VK_W:
	            this.juego.moverArriba();
	            break;
	        case KeyEvent.VK_DOWN:
	        case KeyEvent.VK_S:
	            this.juego.moverAbajo();
	            break;
	        case KeyEvent.VK_LEFT:
	        case KeyEvent.VK_A:
	            this.juego.moverIzquierda();
	            break;
	        case KeyEvent.VK_RIGHT:
	        case KeyEvent.VK_D:
	            this.juego.moverDerecha();
	            break;
	        default:
	            break;
	    }
	    
	    
	    juego.verificaSiGano(); //VERIFICA SI GANO
	    juego.verificaSiPerdio(); // VERIFICA SI PIERDO
	    actualizarInterfaz(); // ME ACTUALIZA PUNTAJES, MOVIMIENTOS Y TABLERO
	}

	private void actualizarInterfaz() {
	    etiquetaPuntaje.setText(juego.obtenerPuntos());
	    etiquetaMovimientos.setText(juego.obtenerCantMovimientos());
	    actualizarMatriz();
	    
	    // VERIFICO SI EL USUARIO GANO 
	    if (juego.juegoGanado()) {
	    	
	    	String puntajeActual = juego.obtenerPuntos();
	        // Cierra esta ventana
	        dispose();
	        // Abre la ventana de juego ganado
	        
	        VentanaGano ventanaGano = new VentanaGano(puntajeActual);
	        ventanaGano.setVisible(true);
	    }
	    
	    if (juego.perdio()) {
	    	String puntajeActual = juego.obtenerPuntos();
	        // Cierra esta ventana
	        dispose();
	        // Abre la ventana de juego ganado
	        VentanaPerdio ventana = new VentanaPerdio(puntajeActual);
	        ventana.setVisible(true);
	    }
	}
	
	public String obtenerPuntaje() {
        return etiquetaPuntaje.getText();
    }

	
	// COLORES PARA LAS CELDAS DE ACUERDO AL NUMERO, DESPUES LO CAMBIAN SI QUIEREN

	private Color obtenerColorParaNumero(int numero) {
		switch (numero) {
		case 2:
			return new Color(238, 228, 218); // Beige para el 2
		case 4:
			return new Color(237, 224, 200); // Otro color para el 4
		case 8:
			return new Color(242, 177, 121); // Y asI sucesivamente...
		case 16:
			return new Color(245, 149, 99);
		case 32:
			return new Color(246, 124, 95);
		case 64:
			return new Color(246, 94, 59);
		case 128:
			return new Color(237, 207, 114);
		case 256:
			return new Color(237, 204, 97);
		case 512:
			return new Color(237, 200, 80);
		case 1024:
			return new Color(237, 197, 63);
		case 2048:
			return new Color(237, 194, 46);
		default:
			return new Color(209, 187, 158); 
		}
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	

}
