package interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaPerdio extends JFrame {
    private JLabel etiquetaPuntaje;

    public VentanaPerdio(String puntaje) {
    	
    	
    	etiquetaPuntaje = new JLabel(puntaje);
        setTitle("¡Oops!");
        setSize(760, 614);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 
        JPanel panel = new JPanel();
        getContentPane().add(panel);
        
       
        BoxLayout layout = new BoxLayout(panel, BoxLayout.Y_AXIS);
        panel.setLayout(layout);

      
        panel.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0)); 

        
        JLabel gameOver = new JLabel("");
        gameOver.setIcon(new ImageIcon(VentanaPerdio.class.getResource("/images/perdiste.png")));
        gameOver.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(gameOver);

        // 
        panel.add(Box.createVerticalStrut(30));

        // NOMBRE Y PUNTAJE
        JLabel nombreYPuntaje = new JLabel();
        VentanaJuego2048 ventanaJuego = new VentanaJuego2048();
        String puntuacion = ventanaJuego.obtenerPuntaje();
        nombreYPuntaje.setText(PantallaMenu.getNombre() + ", puntaje: " + puntaje);
        nombreYPuntaje.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
        nombreYPuntaje.setForeground(new Color(68, 55, 55));
        nombreYPuntaje.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(nombreYPuntaje);

        // 
        panel.add(Box.createVerticalStrut(30));

        JLabel perdiste = new JLabel("");
        perdiste.setIcon(new ImageIcon(VentanaPerdio.class.getResource("/images/2048.png")));
        perdiste.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(perdiste);

       
        panel.add(Box.createVerticalStrut(30));

        // BOTON PARA VOLVER A JUGAR
        JButton volverAJugar = new JButton("Volver a intentar");
        volverAJugar.setForeground(Color.WHITE);
        volverAJugar.setFont(new Font("Comic Sans MS", Font.PLAIN, 13));
        volverAJugar.setPreferredSize(new Dimension(150, 25));
        volverAJugar.setBackground(new Color(239, 128, 80));
        volverAJugar.setBorderPainted(false);
        volverAJugar.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(volverAJugar);

        volverAJugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cierra esta ventana
                dispose();
                // Crea una nueva instancia de la ventana del juego
                VentanaJuego2048 juego = new VentanaJuego2048();
                juego.setVisible(true);
            }
        });
    }


}
