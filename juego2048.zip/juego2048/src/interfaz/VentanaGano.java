package interfaz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class VentanaGano extends JFrame {
	 private JLabel etiquetaPuntaje;
    public  VentanaGano(String puntaje) {
       
    	etiquetaPuntaje = new JLabel(puntaje);
        setTitle("¡Felicidades!");
        setSize(760, 614);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        //PANEL PARA LOS COMPONENTES
        JPanel panel = new JPanel();
        getContentPane().add(panel);
        
       
        BoxLayout layout = new BoxLayout(panel, BoxLayout.Y_AXIS);
        panel.setLayout(layout);

        //ESPACIO PARA LA FOTO Y EL BORDE
        panel.setBorder(BorderFactory.createEmptyBorder(40, 0, 0, 0)); 

        
        JLabel felicidades = new JLabel("");
        felicidades.setIcon(new ImageIcon(VentanaGano.class.getResource("/images/felicidades.png")));
        felicidades.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(felicidades);

        // ESPACIO ENTRE LA  IMAGEN Y TEXTO
        panel.add(Box.createVerticalStrut(30));

        //TEXTO PARA NOMBRE Y PUNTAJE
        JLabel nombreYPuntaje = new JLabel();
        VentanaJuego2048 ventanaJuego = new VentanaJuego2048();
        String puntuacion = ventanaJuego.obtenerPuntaje();
        nombreYPuntaje.setText(PantallaMenu.getNombre() + ", puntaje: " + puntaje);
        nombreYPuntaje.setFont(new Font("Comic Sans MS", Font.BOLD, 25));
        nombreYPuntaje.setForeground(new Color(68, 55, 55));
        nombreYPuntaje.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(nombreYPuntaje);

        // ESPACIO ENTRE TEXTO E IMAGEN
        panel.add(Box.createVerticalStrut(30));

        JLabel ganaste = new JLabel("");
        ganaste.setIcon(new ImageIcon(VentanaGano.class.getResource("/images/2048.png")));
        ganaste.setAlignmentX(Component.CENTER_ALIGNMENT); 
        panel.add(ganaste);

        // ESPACIO ENTRE IMAGEN Y BOTON
        panel.add(Box.createVerticalStrut(30));

        // BOTON PARA VOLVER A JUGAR
        JButton volverAJugar = new JButton("Volver a jugar");
        volverAJugar.setForeground(Color.WHITE);
        volverAJugar.setFont(new Font("Comic Sans MS", Font.PLAIN, 13));
        volverAJugar.setPreferredSize(new Dimension(150, 25));
        volverAJugar.setBackground(new Color(239, 128, 80));
        volverAJugar.setBorderPainted(false);
        volverAJugar.setAlignmentX(Component.CENTER_ALIGNMENT); // Centrar horizontalmente
        panel.add(volverAJugar);

        volverAJugar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Cierra esta ventana
                dispose();
                // Crea una nueva instancia de la ventana del juego
                VentanaJuego2048 juego = new VentanaJuego2048();
                juego.setVisible(true);
            }
        });
    }
   
    public void setPuntaje(String puntaje) {
        etiquetaPuntaje.setText("Puntaje: " + puntaje);
    }
}