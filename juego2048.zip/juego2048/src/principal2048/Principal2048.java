package principal2048;

import interfaz.PantallaMenu;

public class Principal2048 {

	public static void main(String[] args) {
		PantallaMenu window = new PantallaMenu();
		window.frame.setVisible(true);

		

	}

}
