package logica;
import java.util.Random;

public class Tablero {

	private int[][] tablero;
	private int dimension;
	private static int valorParaSumar;

	public Tablero()
	{
		dimension = 4;
		valorParaSumar=0;
		inicializarTablero();
	}

	//Creo un tablero de 4 x 4 y genero un numero 2 o 4 en una posicion random
	private void inicializarTablero()
	{
		tablero = new int[dimension][dimension];
		agregarNumero();
		agregarNumero();
	}
	
	
	
	public void reiniciarTablero()
	{
		inicializarTablero();
	}

	//Verifica que la posicion este dentro del tablero y vacia
	private boolean esPosicionValida(int x, int y)
	{
		return (x >= 0 && x<=dimension - 1 && y >= 0 && y <= dimension - 1 && tablero[x][y] == 0);
	}

	//Crea un random entre 0 y 1. Si es 0 retorna 2, si es 1, retorna 4
	private int generar2o4()
	{
		Random r = new Random();
		int n = r.nextInt(2);    
		return (n == 0) ? 2 : 4;
	}
	
	

	//Genera una posicion que este dentro del tablero y vacia
	
	
	private int[] generarPosicion()
	{
		int[] posicion = new int[2];
		Random r = new Random();

		posicion[0] = r.nextInt(dimension); posicion[1] = r.nextInt(dimension); 

		while(!esPosicionValida(posicion[0], posicion[1]))
		{
			posicion[0] = r.nextInt(dimension); posicion[1] = r.nextInt(dimension); 
		}	
		return posicion;
	}

	//Agrega un 2 o 4 en una posicion random. Chequea que la posicion sea valida
	private void agregarNumero()
	{
		int[] coordenadas = generarPosicion();
		tablero[coordenadas[0]][coordenadas[1]] = generar2o4();
	}

	//Agrega un numero ya que siempre que se actualice el tablero es porque hubo un cambio
	public void actualizarTablero(int[][] tablero) 
	{
		Auxiliar a = new Auxiliar();
		if(a.sonMatricesIguales(tablero, getTablero()) == false) 
		{
			this.tablero = tablero;
			agregarNumero();
		}
	}
	
	//Metodo de movimiento principal, realiza la logica hacia la derecha, los demas movimientos modifican el tablero para usarla
	
	private int[][] mover(int[][] tab) 
	{
	    int[][] nuevoTablero = new int[dimension][dimension];
	
	    for (int i = 0; i < dimension; i++) 
	    {
	        for (int j = 0; j < dimension; j++)
	        {
	            nuevoTablero[i][j] = tab[i][j];
	        }
	    }

	    for (int i = 0; i < dimension; i++) 
	    {
	        while (!estaAlaDerecha(nuevoTablero[i])) 
	        {
	            realizarPermutaciones(nuevoTablero[i]);
	        }
	        realizarSuma(nuevoTablero[i]);
	        realizarPermutaciones(nuevoTablero[i]);
	    }

	    return nuevoTablero;
	}
	
	//Creo una copia de la matriz para modificarla sin afectar el tablero actual, hago los cambios necesarios y luego lo actualizo
	public void moverDerecha() 
	{
		int[][] nuevoTablero = getTablero();
	
		nuevoTablero = mover(nuevoTablero);
		
		actualizarTablero(nuevoTablero);	
	}

	//Creo una copia de la matriz para modificarla sin afectar el tablero actual, hago los cambios necesarios y luego lo actualizo
	public void moverIzquierda() 
	{
		int[][] nuevoTablero = getTablero();
		Auxiliar a = new Auxiliar();
		
		nuevoTablero = a.invertirMatriz(nuevoTablero);
		nuevoTablero = mover(nuevoTablero);
		nuevoTablero = a.invertirMatriz(nuevoTablero);
	
		actualizarTablero(nuevoTablero);
	}

	//Creo una copia de la matriz para modificarla sin afectar el tablero actual, hago los cambios necesarios y luego lo actualizo
	public void moverAbajo()
	{	
		
		int[][] nuevoTablero = getTablero();
		Auxiliar a = new Auxiliar();
		
		nuevoTablero = a.trasponerMatriz(nuevoTablero);
		nuevoTablero = mover(nuevoTablero);
		nuevoTablero = a.trasponerMatriz(nuevoTablero);
	
		actualizarTablero(nuevoTablero);
	}

	//Creo una copia de la matriz para modificarla sin afectar el tablero actual, hago los cambios necesarios y luego lo actualizo
	public void moverArriba() 
	{
		int[][] nuevoTablero = getTablero();
		Auxiliar a = new Auxiliar();
		
		nuevoTablero = a.rotarDerechaMatriz(nuevoTablero);
		nuevoTablero = mover(nuevoTablero);
		nuevoTablero = a.rotarIzquierdaMatriz(nuevoTablero);

		actualizarTablero(nuevoTablero);			
	}

	private static void realizarSuma(int[] a) 
	{
		for(int i = a.length - 2; i >= 0; i--) 
		{
			if(a[i] != 0 && a[i] == a[i + 1]) 
			{
				valorParaSumar= a[i]; //EN ESTA PARTE LE ASIGNO EL VALOR PARA SUMAR
				a[i + 1] = a[i] * 2;
				a[i] = 0;
			}
		}
	}

	public int valorParaSumar() {
		return valorParaSumar;
	}
	
	public void reiniciarValorParaSumar() {
		valorParaSumar=0;
	}
	private static void realizarPermutaciones(int[] a) 
	{
		for(int i = a.length - 2; i>= 0; i--) 
		{
			if(a[i] != 0) 
			{
				if(a[i + 1] == 0) 
				{
					a[i + 1] = a[i];
					a[i] = 0;
				}
			}
		}
	}

	private static boolean estaAlaDerecha(int[] a) 
	{
		boolean b = false;
		for(int i = 0; i<a.length; i++) 
		{
			if(a[i] != 0) 
			{
				b = true;
			}
			else if(b && a[i] == 0) 
			{
				return false;
			}
		}
		return true;
	}
	
	//Retorna un String con el tablero. Lo va a usar la interfaz grafica
	public String obtenerTableroString()
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < tablero.length; i++)
		{
			for (int j = 0; j < tablero[i].length; j++) 
			{
				sb.append(tablero[i][j] == 0 ? " " : tablero[i][j]).append("\t");
			}
			sb.append("\n"); sb.append("\n");
		}
		return sb.toString();
	}
	
	public int[][] getTablero()
	{
		return this.tablero;
	}
	
	
	public boolean hayMovimientosDisponibles() 
	{
		for(int i = 0; i<dimension; i++) 
		{
			for(int j = 0; j<dimension; j++) 
			{			
				
				if(tablero[i][j] == 0) {
					return true;
				}
				
			}
		}
		return false;
	}
	
	// VERIFICA SI GANO
	public boolean gano() {
	    for (int i = 0; i < dimension; i++) {
	        for (int j = 0; j < dimension; j++) {
	            if (tablero[i][j] == 2048) { 
	                return true;
	            }
	        }
	    }
	    return false;
	}
	
}
