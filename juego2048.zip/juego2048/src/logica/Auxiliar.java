package logica;

public class Auxiliar {
	
	public Auxiliar() 
	{
		//Clase utilizada para diferenciar el codigo que hace operaciones con matrices del de la logica del tablero
	}

	//METODO AUXILIAR 1
	public int[][] trasponerMatriz(int[][] matriz) 
	{
		int[][] nuevaMatriz = new int[matriz.length][matriz.length];
		for (int i = 0; i < matriz.length; i++)
		{
			for (int j = 0; j < matriz.length; j++)
			{
				nuevaMatriz[j][i] = matriz[i][j];
			}
		}
		return nuevaMatriz;
	}

	//METODO AUX 2
	public int[][] rotarDerechaMatriz(int[][] matriz) 
	{
		int[][] nuevaMatriz = new int[matriz.length][matriz.length];
		for (int i = 0; i < matriz.length; i++)
		{
			for (int j = 0; j < matriz.length; j++) 
			{
				nuevaMatriz[j][matriz.length - 1 - i] = matriz[i][j];
			}
		}
		return nuevaMatriz;
	}

	//METODO AUX 3
	public int[][] rotarIzquierdaMatriz(int[][] matriz)
	{
		int[][] nuevaMatriz = new int[matriz.length][matriz.length];
		for (int i = 0; i < matriz.length; i++)
		{
			for (int j = 0; j < matriz.length; j++) 
			{
				nuevaMatriz[matriz.length - 1 - j][i] = matriz[i][j];
			}
		}
		return nuevaMatriz;
	}
	
	//METODO AUX 4
	public int[][] invertirMatriz(int[][] matriz)
	{
	    int[][] nuevaMatriz = new int[matriz.length][matriz.length];
	    for (int i = 0; i < matriz.length; i++) 
	    {
	        for (int j = 0; j < matriz.length; j++)
	        {
	            nuevaMatriz[i][j] = matriz[i][matriz.length - 1 - j];
	        }
	    }
	    return nuevaMatriz;
	}
	
	//METODO AUX 5
	public boolean sonMatricesIguales(int[][] matriz1, int[][] matriz2)
	{
	    if (matriz1.length != matriz2.length || matriz1[0].length != matriz2[0].length) 
	    {
	    	return false;
	    }
	    for (int i = 0; i < matriz1.length; i++)
	    {
	        for (int j = 0; j < matriz1[0].length; j++) 
	        {
	            if (matriz1[i][j] != matriz2[i][j]) 
	            {
	            	return false;
	            }
	        }
	    }
	    return true;
	}
	
	
	
	
	
	
}
