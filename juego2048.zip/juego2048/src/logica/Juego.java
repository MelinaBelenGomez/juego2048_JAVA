package logica;

public class Juego
{

	private Tablero tablero;
	private int puntaje;
	private int cantMovimientos;
	private String jugador;
	private boolean gameOver;
	private boolean juegoGanado;
	
	public Juego(String jugador)
	
	{	jugador= jugador;
		tablero = new Tablero();
		puntaje = 0;
		cantMovimientos = 0;
		gameOver = false;
		juegoGanado= false;
		
	}
	
	public String jugador() {
		return jugador;
	}
	
	public int[][] dameTablero(){
		return tablero.getTablero();
	}
		
	
	public void verificaSiPerdio() {
		if(!tablero.hayMovimientosDisponibles()) {
			gameOver=true;
		}
	}
	
		
	public void verificaSiGano() {
		if (tablero.gano() && !gameOver) {
			juegoGanado= true;
		}
	
	}
	public boolean juegoGanado() {
		return this.juegoGanado;
	}
	
	public boolean perdio() {
		return this.gameOver;
	}
	
	public void moverDerecha() 
	{
		tablero.moverDerecha();
		sumarPuntaje(tablero.valorParaSumar()); //SOLO SUMA AL PUNTAJE CUANDO SE HAYA HECHO UNA SUMA VALIDA
											//EJEMPLO SI SE SUMO 2+2, SOLO SUME 2 AL PUNTAJE
		
		tablero.reiniciarValorParaSumar(); //REINICIO EL VALOR PARA SUMAR A 0 ASI SE ACTUALIZA CON OTRAS SUMAS DEL TABLERO
		sumarMovimientos();
	
	}
	
	public void moverIzquierda() 
	{
		tablero.moverIzquierda();
		sumarPuntaje(tablero.valorParaSumar());
		tablero.reiniciarValorParaSumar();
		sumarMovimientos();
		
	}
	
	public void moverArriba() 
	{
		tablero.moverArriba();
		sumarPuntaje(tablero.valorParaSumar());
		tablero.reiniciarValorParaSumar();
		sumarMovimientos();
		
	}
	
	public void moverAbajo() 
	{
		tablero.moverAbajo();
		sumarPuntaje(tablero.valorParaSumar());
		tablero.reiniciarValorParaSumar();
		sumarMovimientos();
	
	}
	
	public int puntos() {
		return puntaje;
	}

	public String obtenerPuntos() {
		return Integer.toString(puntaje);
	}
	

	public String obtenerCantMovimientos() {
		return Integer.toString(cantMovimientos);
	}
	
	
	public void finalizarJuego() 
	{
		gameOver = true;
	}
	
	private void sumarPuntaje(int valorSumado) 
	{
		puntaje += valorSumado;
	}
	
	private void sumarMovimientos() 
	{
		cantMovimientos++;
	}
	
	
	
	
	
}
